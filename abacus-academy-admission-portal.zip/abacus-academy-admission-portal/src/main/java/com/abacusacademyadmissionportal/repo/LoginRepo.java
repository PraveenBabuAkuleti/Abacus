package com.abacusacademyadmissionportal.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.abacusacademyadmissionportal.entity.LoginModel;

@Component
public interface LoginRepo extends JpaRepository<LoginModel, Integer> {

}
