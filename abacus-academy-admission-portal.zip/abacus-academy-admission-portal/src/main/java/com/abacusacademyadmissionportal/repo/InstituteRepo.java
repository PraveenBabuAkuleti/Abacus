package com.abacusacademyadmissionportal.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.abacusacademyadmissionportal.entity.InstituteModel;

@Component
public interface InstituteRepo extends JpaRepository<InstituteModel, Integer> {

}
