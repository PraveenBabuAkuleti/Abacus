package com.abacusacademyadmissionportal.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import com.abacusacademyadmissionportal.entity.UserModel;

@Component
public interface UserRepo extends JpaRepository<UserModel, String> {

}
