package com.abacusacademyadmissionportal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abacusacademyadmissionportal.entity.StudentModel;
import com.abacusacademyadmissionportal.repo.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepo studentRepo;

	@Override
	public StudentModel addStudent(StudentModel student) {
		return studentRepo.save(student);
	}

	@Override
	public Optional<StudentModel> getStudentById(Integer id) {
		return studentRepo.findById(id);
	}

	@Override
	public Iterable<StudentModel> getStudentList() {
		// TODO Auto-generated method stub
		return studentRepo.findAll();
	}

	@Override
	public StudentModel updateStudent(StudentModel student) {
		// TODO Auto-generated method stub
		return studentRepo.save(student);
	}

	@Override
	public void delete(Integer id) {
		studentRepo.deleteById(id);

	}

}
