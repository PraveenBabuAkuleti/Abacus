package com.abacusacademyadmissionportal.service;

import java.util.List;
import java.util.Optional;

import com.abacusacademyadmissionportal.entity.StudentModel;

public interface StudentService {

	public StudentModel addStudent(StudentModel student);

	public Optional<StudentModel> getStudentById(Integer id);

	public Iterable<StudentModel> getStudentList();

	public StudentModel updateStudent(StudentModel student);

	public void delete(Integer id);

}
