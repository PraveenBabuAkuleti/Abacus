package com.abacusacademyadmissionportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class InstituteModel {
	
	@Id
	@Column
	private int instituteId;
	@Column
	private String instituteName;
	@Column
	private String instituteDescription;
	
	public int getInstituteId() {
		return instituteId;
	}
	public void setInstituteId(int instituteId) {
		this.instituteId = instituteId;
	}
	public String getInstituteName() {
		return instituteName;
	}
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}
	public String getInstituteDescription() {
		return instituteDescription;
	}
	public void setInstituteDescription(String instituteDescription) {
		this.instituteDescription = instituteDescription;
	}
	@Override
	public String toString() {
		return "InstituteModel [instituteId=" + instituteId + ", instituteName=" + instituteName
				+ ", instituteDescription=" + instituteDescription + "]";
	}
	
	
}	
