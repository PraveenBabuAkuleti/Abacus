package com.abacusacademyadmissionportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbacusAcademyAdmissionPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
